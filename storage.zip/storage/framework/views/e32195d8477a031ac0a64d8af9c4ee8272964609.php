<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>Outstock - Clean, Minimal eCommerce HTML5 Template </title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Place favicon.ico in the root directory -->
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('img/favicon.png')); ?>">   <?php /**PATH /home/pigstuhq/pureoproducts.pigslhub.com/resources/views/front/includes/partials/head.blade.php ENDPATH**/ ?>