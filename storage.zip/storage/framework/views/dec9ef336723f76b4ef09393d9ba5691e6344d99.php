<link rel="stylesheet" href="<?php echo e(asset('front/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('front/css/preloader.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('front/css/slick.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('front/css/metismenu.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('front/css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('front/css/animate.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('front/css/jquery.fancybox.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('front/css/fontawesome5pro.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('front/css/ionicons.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('front/css/default.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('front/css/style.css')); ?>"><?php /**PATH /home/pigstuhq/pureoproducts.pigslhub.com/resources/views/front/includes/partials/style.blade.php ENDPATH**/ ?>