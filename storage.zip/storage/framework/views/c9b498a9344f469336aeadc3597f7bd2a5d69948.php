<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>PureONaturalProducts | Best Natrual Products Provider </title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Place favicon.ico in the root directory -->
<link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">
<?php /**PATH /home/pigstuhq/pureoproducts.pigslhub.com/resources/views/frontend/includes/partials/head.blade.php ENDPATH**/ ?>