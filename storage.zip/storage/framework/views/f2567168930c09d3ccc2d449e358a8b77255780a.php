<?php echo $__env->yieldContent('styles'); ?>
<!-- Bootstrap css-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
<!-- App css-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">
<!-- Responsive css-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/responsive.css')); ?>">


<?php /**PATH /home/pigstuhq/pureoproducts.pigslhub.com/resources/views/errors/layouts/style.blade.php ENDPATH**/ ?>