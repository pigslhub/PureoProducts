 <?php echo $__env->yieldContent('scripts'); ?>
<?php /**PATH /home/pigstuhq/pureoproducts.pigslhub.com/resources/views/errors/layouts/script.blade.php ENDPATH**/ ?>