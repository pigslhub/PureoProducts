<!-- CSS here -->
<link rel="stylesheet" href="<?php echo e(asset('frontend/')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/slick.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/metisMenu.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/animate.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/jquery.fancybox.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/fontAwesome5Pro.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/ionicons.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/default.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/style.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/toastr.min.css')); ?>">
<?php /**PATH /home/pigstuhq/pureoproducts.pigslhub.com/resources/views/frontend/includes/partials/styles.blade.php ENDPATH**/ ?>